// 引入 wxParse（保留的用法）
const WxParse = require('../../wxParse/wxParse.js');

Page({
  data: {
    // —— 知识图谱缩放外壳（保留的） ——
    kgScaleValue: 1, kgScaleMin: 1, kgScaleMax: 3, kgStep: 0.2, kgX: 0, kgY: 0, _zoomLock: false,

    // —— 会话与聊天（保留的） ——
    sessions: [],
    activeSessionId: '',
    messages: [],
    status: 'idle',
    inputValue: '',
    canSend: true,
    scrollToId: '',
    showSider: false,

    // —— 新增：图谱数据与画布状态 ——
    kgLoading: false,
    kgError: '',
    kgData: null,          // {source, targets[]}
    kgSelectedName: '',
  },

  // 非 data：画布上下文与几何
  _kg: {
    ctx: null,
    canvas: null,
    dpr: 1,
    w: 0,
    h: 0,
    nodes: [],    // [{name,type,x,y,r}]
    edges: [],    // [{from:idx,to:idx,desc,weight}]
  },

  // 可配置：后端接口地址 & 初始节点（可留空，等用户从别处带入）
  apiKgUrl: 'https://your-api/kg/relations', // TODO 替换成真实接口
  kgEntryName: '', // 例如 '风热感冒' 或 '黄连'，留空则首屏不请求

  /* ================= 生命周期 ================= */
  onLoad() {
    // 1) 先把对话欢迎语准备好
    this._bootstrapSessions();

    // 2) 初始化 2D canvas
    this._initCanvas(() => {
      // 3) 可选：如果有默认入口节点，加载图谱
      if (this.kgEntryName) {
        this._loadKg(this.kgEntryName, { autoAsk: false });
      }
    });
  },

  /* ================= 画布 & 图谱 ================= */

  _initCanvas(done) {
    const query = wx.createSelectorQuery();
    query.select('#kgCanvas').fields({ node: true, size: true }).exec(res => {
      const ret = res && res[0];
      if (!ret || !ret.node) {
        console.warn('kgCanvas 未获取到');
        done && done();
        return;
      }
      const canvas = ret.node;
      const ctx = canvas.getContext('2d');
      const dpr = wx.getSystemInfoSync().pixelRatio || 1;
      // 设置像素比，保证清晰
      canvas.width = Math.floor(ret.width * dpr);
      canvas.height = Math.floor(ret.height * dpr);
      ctx.scale(dpr, dpr);

      this._kg.canvas = canvas;
      this._kg.ctx = ctx;
      this._kg.dpr = dpr;
      this._kg.w = ret.width;
      this._kg.h = ret.height;
      this._drawGraph(); // 初始清屏
      done && done();
    });
  },

  _loadKg(name, opts = {}) {
    if (!name) return;
    this.setData({ kgLoading: true, kgError: '' });
    wx.request({
      url: this.apiKgUrl,
      method: 'GET',
      data: { name }, // 若后端需要 POST 或字段名不同，请在此处调整
      timeout: 15000,
      success: (res) => {
        const data = res.data;
        if (!data || !data.source) {
          this.setData({ kgLoading: false, kgError: '未获取到图谱数据' });
          return;
        }
        this.setData({ kgData: data, kgLoading: false, kgSelectedName: data.source.name });
        this._buildGraphFromData(data);
        // 点击节点后自动问答
        if (opts.autoAsk) {
          this._askAiForNode(data.source.name, data.source.type);
        }
      },
      fail: () => {
        this.setData({ kgLoading: false, kgError: '图谱接口异常，请稍后重试' });
      }
    });
  },

  _buildGraphFromData(data) {
    // 简单星形布局：中心点 + 环形分布 targets
    const { w, h } = this._kg;
    const cx = w / 2, cy = h / 2;
    const R = Math.max(100, Math.min(w, h) / 2 - 40); // 环半径
    const centerR = 18;
    const leafR = 14;

    const nodes = [];
    const edges = [];

    // center
    nodes.push({
      name: data.source.name,
      type: data.source.type,
      x: cx,
      y: cy,
      r: centerR,
    });

    const t = (data.targets || []).length;
    for (let i = 0; i < t; i++) {
      const angle = (Math.PI * 2 * i) / Math.max(1, t);
      const tx = cx + R * Math.cos(angle);
      const ty = cy + R * Math.sin(angle);
      const te = data.targets[i]?.target_entity || {};
      const desc = data.targets[i]?.description || '';

      nodes.push({
        name: te.name,
        type: te.type,
        x: tx,
        y: ty,
        r: leafR,
      });

      // 尝试把关系描述当作数值权重（若能解析）
      let weight = parseFloat(desc);
      if (!isFinite(weight)) weight = 1;

      edges.push({
        from: 0,             // 从中心到外圈
        to: i + 1,
        desc,
        weight,
      });
    }

    this._kg.nodes = nodes;
    this._kg.edges = edges;
    this._drawGraph();
  },

  _drawGraph() {
    const { ctx, w, h, nodes, edges } = this._kg;
    if (!ctx) return;

    // 清屏
    ctx.clearRect(0, 0, w, h);

    // 背景网格（可选）
    ctx.save();
    ctx.strokeStyle = 'rgba(0,0,0,0.04)';
    ctx.lineWidth = 1;
    for (let x = 0; x <= w; x += 40) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke();
    }
    for (let y = 0; y <= h; y += 40) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke();
    }
    ctx.restore();

    // 画边（带箭头与权重/描述）
    edges.forEach(e => {
      const a = nodes[e.from], b = nodes[e.to];
      if (!a || !b) return;
      this._drawArrow(a.x, a.y, b.x, b.y, e);
    });

    // 画节点
    nodes.forEach(n => {
      this._drawNode(n);
    });
  },

  _nodeColorByType(type) {
    // 粗分：药材/病症；其他默认
    if (!type) return '#4a90e2';
    if (type.includes('药') || /herb/i.test(type)) return '#3aa675';
    if (type.includes('病') || /disease|illness/i.test(type)) return '#b94a48';
    return '#4a90e2';
  },

  _drawNode(n) {
    const { ctx } = this._kg;
    const color = this._nodeColorByType(n.type);
    const isSelected = (n.name === this.data.kgSelectedName);

    // 外圈高亮
    if (isSelected) {
      ctx.beginPath();
      ctx.arc(n.x, n.y, n.r + 4, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(188, 143, 79, .15)';
      ctx.fill();
    }

    // 圆点
    ctx.beginPath();
    ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.fill();

    // 文本
    ctx.fillStyle = '#fff';
    ctx.font = '12px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const label = (n.name || '').slice(0, 6);
    ctx.fillText(label, n.x, n.y);
  },

  _drawArrow(x1, y1, x2, y2, e) {
    const { ctx } = this._kg;
    const dx = x2 - x1, dy = y2 - y1;
    const ang = Math.atan2(dy, dx);
    const head = 10; // 箭头尺寸
    const lw = 1.2 + Math.min(3, (e.weight || 1) * 0.6); // 线宽随权重

    // 主线
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.strokeStyle = '#8c5721';
    ctx.lineWidth = lw;
    ctx.stroke();

    // 箭头
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(x2 - head * Math.cos(ang - Math.PI / 6), y2 - head * Math.sin(ang - Math.PI / 6));
    ctx.lineTo(x2 - head * Math.cos(ang + Math.PI / 6), y2 - head * Math.sin(ang + Math.PI / 6));
    ctx.closePath();
    ctx.fillStyle = '#8c5721';
    ctx.fill();

    // 关系文字（描述）
    if (e.desc) {
      const mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
      ctx.fillStyle = 'rgba(0,0,0,0.6)';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.fillText(String(e.desc).slice(0, 10), mx, my - 6);
    }
    ctx.restore();
  },

  onCanvasTap(ev) {
    // 命中检测：找最近的节点且在半径内
    const { x, y } = this._eventXY(ev);
    const hit = this._hitNode(x, y);
    if (!hit) return;

    // 选中并加载其关系；加载完成后自动问答
    this.setData({ kgSelectedName: hit.name }, () => {
      this._drawGraph();
    });
    this._loadKg(hit.name, { autoAsk: true });
  },

  _eventXY(ev) {
    // 兼容 tap / touchstart
    let x = ev.detail?.x, y = ev.detail?.y;
    if (typeof x !== 'number' || typeof y !== 'number') {
      const t = ev.touches && ev.touches[0];
      if (t) { x = t.x; y = t.y; }
    }
    // 已经用 dpr scale 过 ctx，因此这里返回 CSS 像素坐标即可
    return { x, y };
  },

  _hitNode(x, y) {
    const { nodes } = this._kg;
    if (!nodes || !nodes.length) return null;
    let best = null, bestD2 = 1e9;
    nodes.forEach(n => {
      const d2 = (x - n.x) * (x - n.x) + (y - n.y) * (y - n.y);
      if (d2 <= (n.r + 6) * (n.r + 6) && d2 < bestD2) {
        bestD2 = d2; best = n;
      }
    });
    return best;
  },

  _askAiForNode(name, type) {
    const prompt = this._promptForNode(name, type);
    // 直接发送到智能问答
    this._send(prompt);
  },

  _promptForNode(name, type) {
    const t = (type || '').toLowerCase();
    if (type.includes('药') || /herb/.test(t)) {
      return `请介绍药材「${name}」的性味归经、功效与常用配伍，结合吴门医派的特点说明适用证候与禁忌。`;
    }
    if (type.includes('病') || /disease|illness/.test(t)) {
      return `针对病症「${name}」，请按吴门医派思路给出辨证要点、常见证型、治法方药及加减思路。`;
    }
    return `请结合吴门医派知识，介绍与「${name}」相关的关键概念、辨证与治疗思路。`;
  },

  /* ================= 侧栏折叠（保留） ================= */
  toggleSider(){ this.setData({ showSider: !this.data.showSider }) },
  hideSider(){ this.setData({ showSider: false }) },

  /* ================= 知识图谱缩放外壳（保留的） ================= */
  onKgScale(e){ this.kgCurrentScale = e.detail.scale || this.kgCurrentScale },
  _clampAndSnap(val){ const { kgScaleMin, kgScaleMax, kgStep } = this.data; const c = Math.max(kgScaleMin, Math.min(kgScaleMax, val)); const s = Math.round(c / kgStep) * kgStep; return Number(s.toFixed(4)); },
  _withZoomLock(fn){ if(this.data._zoomLock) return; this.setData({ _zoomLock: true }); try{ fn() }finally{ setTimeout(()=>this.setData({ _zoomLock:false }),120)} },
  zoomIn(){ this._withZoomLock(()=>{ const n=this._clampAndSnap(this.kgCurrentScale + this.data.kgStep); if(n>this.kgCurrentScale){ this.kgCurrentScale=n; this.setData({kgScaleValue:n}) } else if(this.kgCurrentScale>=this.data.kgScaleMax-1e-6){ wx.showToast({title:'已放大到最大',icon:'none'}) } }) },
  zoomOut(){ this._withZoomLock(()=>{ const n=this._clampAndSnap(this.kgCurrentScale - this.data.kgStep); if(n<this.kgCurrentScale){ this.kgCurrentScale=n; this.setData({kgScaleValue:n}) } else if(this.kgCurrentScale<=this.data.kgScaleMin+1e-6){ wx.showToast({title:'已缩小到最小',icon:'none'}) } }) },
  resetKG(){ this.kgCurrentScale=1; this.setData({ kgScaleValue:1, kgX:0, kgY:0 }) },

  /* ================= 会话管理（保留的并加欢迎语保障 + Markdown 解析） ================= */

  _bootstrapSessions(){
    const cache = wx.getStorageSync('wm_kg_sessions') || [];
    if (cache.length) {
      const sid = cache[0].id;
      const msgs = (cache[0].messages || []).map(m => this._withParsed(m));
      this.setData({ sessions: cache, activeSessionId: sid, messages: msgs }, () => {
        this._ensureWelcome();
      });
    } else {
      const sid = this._createInitialSession([]);
      const s = wx.getStorageSync('wm_kg_sessions')[0];
      const msgs = (s.messages || []).map(m => this._withParsed(m));
      this.setData({ sessions: wx.getStorageSync('wm_kg_sessions'), activeSessionId: sid, messages: msgs }, () => {
        this._ensureWelcome();
      });
    }
  },

  _ensureWelcome(){
    const sessions = this.data.sessions.slice();
    const s = sessions.find(x => x.id === this.data.activeSessionId);
    if (!s) return;
    const hasAi = (s.messages || []).some(m => m.role === 'ai');
    if (!hasAi) {
      const welcome = { id: Date.now(), role:'ai', text:'您好，我是基于吴门医派知识的AI助手，请问有什么可以帮您？', time: this._time() };
      s.messages = [welcome, ...(s.messages || [])];
      this._saveSessions(sessions, this.data.activeSessionId, s.messages.map(m => this._withParsed(m)));
    } else {
      // 确保已有消息也被解析
      const parsed = (s.messages || []).map(m => this._withParsed(m));
      this._saveSessions(sessions, this.data.activeSessionId, parsed);
    }
  },

  onNewSession(){
    const sessions = this.data.sessions.slice();
    const id = Date.now().toString(36);
    const title = '新的会话';
    const welcome = { id: Date.now(), role:'ai', text:'您好，我是基于吴门医派知识的AI助手，请问有什么可以帮您？', time: this._time() };
    sessions.unshift({ id, title, updatedAt: Date.now(), messages: [welcome] });
    // 解析欢迎语
    const mirror = sessions[0].messages.map(m => this._withParsed(m));
    this._saveSessions(sessions, id, mirror);
  },

  onPickSession(e){
    const id = e.currentTarget.dataset.id;
    const s = this.data.sessions.find(x=>x.id===id);
    if (!s) return;
    const msgs = (s.messages || []).map(m => this._withParsed(m));
    this.setData({ activeSessionId:id, messages: msgs, scrollToId: '' });
  },

  onRenameSession(e){
    const id = e.currentTarget.dataset.id;
    const s = this.data.sessions.find(x=>x.id===id); if(!s) return;
    wx.showModal({
      title:'重命名会话', editable:true, placeholderText:'输入新名称', content: s.title,
      success: (r)=>{
        if(r.confirm){
          s.title = (r.content||'').trim() || s.title;
          s.updatedAt = Date.now();
          this._saveSessions(this.data.sessions.slice());
        }
      }
    });
  },

  onDeleteSession(e){
    const id = e.currentTarget.dataset.id;
    wx.showModal({
      title:'删除会话', content:'确定删除该会话及其消息？不可恢复。',
      success: (r)=>{
        if(!r.confirm) return;
        let sessions = this.data.sessions.slice();
        const idx = sessions.findIndex(x=>x.id===id);
        if(idx>=0) sessions.splice(idx,1);
        let active = this.data.activeSessionId;
        if (active===id){
          if (sessions.length===0){
            const newId = this._createInitialSession(sessions);
            sessions = wx.getStorageSync('wm_kg_sessions');
            active = newId;
          } else {
            active = sessions[0].id;
          }
        }
        const cur = sessions.find(x=>x.id===active);
        const mirror = (cur?.messages || []).map(m => this._withParsed(m));
        this._saveSessions(sessions, active, mirror);
      }
    });
  },

  _createInitialSession(existing){
    const sessions = existing ? existing.slice() : [];
    const id = Date.now().toString(36);
    const welcome = { id: Date.now(), role:'ai', text:'您好，我是基于吴门医派知识的AI助手，请问有什么可以帮您？', time: this._time() };
    sessions.unshift({ id, title:'新的会话', updatedAt: Date.now(), messages: [welcome] });
    wx.setStorageSync('wm_kg_sessions', sessions);
    return id;
  },

  _saveSessions(sessions, activeId, messagesMirror){
    wx.setStorageSync('wm_kg_sessions', sessions);
    if (activeId){
      this.setData({
        sessions,
        activeSessionId: activeId,
        messages: messagesMirror ?? (sessions.find(s=>s.id===activeId)?.messages || [])
      });
    } else {
      this.setData({ sessions });
    }
  },

  /* ================= 输入 & 发送（保留 + Markdown 解析） ================= */

  onInput(e){
    const v = e.detail.value;
    const sending = this.data.status!=='idle';
    this.setData({ inputValue: v, canSend: !!v.trim() && !sending });
  },
  onConfirm(){ this._send(this.data.inputValue) },
  onSendTap(){ this._send(this.data.inputValue) },

  _send(text){
    if (this.data.status!=='idle') return;
    const msg = (text||'').trim(); if(!msg) return;
    const userMsg = { id: Date.now(), role:'user', text: msg, time: this._time() };

    const sessions = this.data.sessions.slice();
    const s = sessions.find(x=>x.id===this.data.activeSessionId); if(!s) return;
    s.messages.push(userMsg); s.updatedAt = Date.now();
    this._saveSessions(sessions);
    this.setData({
      messages: s.messages,
      inputValue: '',
      canSend: false,
      status: 'thinking',
      scrollToId: `msg-${userMsg.id}`
    }, ()=> this._callChatAPI(s.messages));
  },

  _callChatAPI(history){
    const payload = {
      messages: history.slice(-12).map(m=>({ role: m.role==='ai'?'assistant':m.role, content: m.text }))
    };
    const aiId = Date.now()+1;
    const aiMsg = { id: aiId, role:'ai', text:'', display:'', time: this._time(), streaming:true };

    const sessions = this.data.sessions.slice();
    const s = sessions.find(x=>x.id===this.data.activeSessionId); if(!s) return;
    s.messages.push(aiMsg); s.updatedAt = Date.now();
    this._saveSessions(sessions);
    this.setData({ messages: s.messages, status:'answering', scrollToId:`msg-${aiId}` });

    wx.request({
      url: 'https://your-api/chat-stream', // TODO
      method: 'POST',
      data: payload,
      timeout: 30000,
      success: (res)=>{
        const chunks = res.data?.chunks;
        const final = res.data?.answer;
        if (Array.isArray(chunks) && chunks.length){
          this._appendChunks(aiId, chunks, true);
        } else if (typeof final === 'string'){
          this._fakeStream(aiId, final);
        } else {
          this._finish(aiId, '（暂无回答）');
        }
      },
      fail: ()=>{
        this._finish(aiId, '抱歉，服务暂时不可用，请稍后重试。');
      }
    });
  },

  _appendChunks(aiId, chunks, persistOnEnd=true){
    let i=0;
    const tick=()=>{
      if(i>=chunks.length){ this._finalizeStreaming(aiId, persistOnEnd); return; }
      const part=String(chunks[i++]||'');
      this._append(aiId, part);
      this.setData({ scrollToId:`msg-${aiId}` });
      setTimeout(tick, 30);
    };
    tick();
  },
  _fakeStream(aiId, full){ const pieces = full.split(/(\s+|，|。|；|！|？)/).filter(Boolean); this._appendChunks(aiId, pieces, true); },

  _append(aiId, piece){
    const sessions = this.data.sessions.slice();
    const s = sessions.find(x=>x.id===this.data.activeSessionId); if(!s) return;
    const idx = s.messages.findIndex(m=>m.id===aiId); if(idx<0) return;
    const old = s.messages[idx];
    const nextText = (old.text||'') + piece;
    // Markdown 解析（方案一：返回 nodes）
    let parsed = null;
    try {
      parsed = WxParse.wxParseReturn(nextText, 'md');
    } catch (e) {}
    s.messages[idx] = { ...old, text: nextText, display: nextText, parsed: { nodes: parsed || [] }, streaming:true };
    this._saveSessions(sessions);
  },

  _finalizeStreaming(aiId){
    const sessions = this.data.sessions.slice();
    const s = sessions.find(x=>x.id===this.data.activeSessionId); if(!s) return;
    const idx = s.messages.findIndex(m=>m.id===aiId); if(idx>=0){
      const msg = s.messages[idx];
      let parsed = null;
      try { parsed = WxParse.wxParseReturn(msg.text, 'md'); } catch(e){}
      s.messages[idx] = { ...msg, streaming:false, parsed: { nodes: parsed || [] }, time:this._time() };
    }
    this._saveSessions(sessions);
    this.setData({ status:'idle', canSend:true, scrollToId:`msg-${aiId}` });
  },

  _finish(aiId, text){
    const sessions = this.data.sessions.slice();
    const s = sessions.find(x=>x.id===this.data.activeSessionId); if(!s) return;
    const idx = s.messages.findIndex(m=>m.id===aiId); if(idx>=0){
      let parsed = null;
      try { parsed = WxParse.wxParseReturn(text, 'md'); } catch(e){}
      s.messages[idx] = { ...s.messages[idx], streaming:false, text, display:text, parsed:{ nodes: parsed || [] }, time:this._time() };
    }
    this._saveSessions(sessions);
    this.setData({ status:'idle', canSend:true, scrollToId:`msg-${aiId}` });
  },

  // 公共：AI 消息预解析
  _withParsed(msg){
    if (msg.role !== 'ai') return msg;
    const md = (msg.display || msg.text || '').trim();
    let nodes = [];
    try { nodes = WxParse.wxParseReturn(md, 'md') || []; } catch(e){}
    return { ...msg, parsed: { nodes } };
  },

  /* ================= 其它保留 ================= */
  noop(){},
  _time(){ const d=new Date(); return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`; },
});